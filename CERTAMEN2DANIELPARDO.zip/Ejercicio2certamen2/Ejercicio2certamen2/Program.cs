﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2certamen2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] matriz = new string[8, 8];

            for(int a = 0; a < matriz.GetLength(0); a++)
            {
                    for (int b = 0; b < matriz.GetLength(1); b++)
                    {
                        if (a == 3 || a == 4 || b == 3 || b == 4)
                            matriz[a, b] = "1";
                        else
                            matriz[a, b] = "0";
                     }
              
            }
            imprimir(matriz);
            Console.ReadKey();

        }
        static void imprimir(string[,] matriz)
        {
            for (int a = 0; a < matriz.GetLength(0); a++)
            {
                for (int b = 0; b < matriz.GetLength(0); b++)
                {
                    Console.Write(matriz[a, b] + "");
                }
                Console.WriteLine();
            }
        }
    }

    
}
