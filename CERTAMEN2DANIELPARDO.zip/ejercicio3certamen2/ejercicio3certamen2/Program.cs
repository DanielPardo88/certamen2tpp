﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3certamen2
{
    class Program
    {
        static void Main(string[] args)
        {
            var random = new Random();
            int[] vtor = new int[10];
            int myr = vtor[0];
            int mnr = vtor[0];
            int myrpos = 1;
            int mnrpos = 1;             
            
            for (int i=0; i < vtor.Length; i++)
            {
                vtor[i] = random.Next(50, 200);
            }           
            Console.WriteLine();            
           
            for (int i=0; i < vtor.Length; i++)
            {
                if (vtor[i] > myr)
                {
                    myrpos = i;
                    myr = vtor[i];
                }
            }
            Console.WriteLine("numero mayor del arreglo es:" + myr);
            Console.WriteLine("Su posicion es: "+ myrpos);

            for (int i=0; i < vtor.Length; i++)
            {
                if (vtor[i] < mnr)
                {
                    mnrpos = i;
                    mnr = vtor[i];
                }
            }
            Console.WriteLine("menor numero es:" + vtor.Min());
            Console.WriteLine("mayor numero es:" + vtor.Max());
            Console.WriteLine("numero menor del arreglo es:" + mnr);
            Console.WriteLine("Su posicion es: " + mnrpos);
            imprimirvector(vtor);
            Console.ReadKey();

        }
        static void imprimirvector(int[] vtor)
        {
            for (int i = 0; i < vtor.Length; i++)
            {
                Console.Write(vtor[i] + "");
            }
        }

    }
}
